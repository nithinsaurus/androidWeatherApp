package com.example.weatherapp;
import org.json.JSONObject;

public interface JSONGetter {
    void populate(JSONObject data);
}